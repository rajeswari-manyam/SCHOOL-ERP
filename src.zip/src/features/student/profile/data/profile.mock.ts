import type { Student } from "../types/profile.types";

export const STUDENT_DATA: Student = {
  id:             "stu-001",
  admissionNo:    "ADM-001",
  rollNo:         "01",
  name:           "Ravi Kumar",
  avatarInitials: "RK",
  avatarColor:    "#4f46e5",
  status:         "ACTIVE",
  className:      "Class 10A",
  section:        "A",
  schoolCode:     "",
  rawClass:       "10",
  classTeacher: {
    id:             "tch-001",
    name:           "Not assigned",
    title:          "",
    avatarInitials: "--",
  },
  academic: {
    academicYear: "2024-25",
    board:        "CBSE",
    section:      "A",
    classroom:    "Room 501",
  },
  personal: {
    dateOfBirth: "12 March 2009",
    gender:      "Male",
    bloodGroup:  "B+",
    age:         16,
    fullAddress: "Plot 12, Hanamkonda Urban, Warangal — 506001",
  },
  quickDownloads: [
    {
      id:       "dl-001",
      title:    "Latest Report Card — 2024-25",
      subtitle: "ACADEMIC DOCUMENT",
      type:     "ACADEMIC",
      fileSize: "1.2 MB",
    },
    {
      id:       "dl-002",
      title:    "Student ID Card",
      subtitle: "IDENTITY DOCUMENT",
      type:     "IDENTITY",
      fileSize: "0.8 MB",
    },
    {
      id:           "dl-003",
      title:        "Latest Fee Receipt — RCP-2025-0823",
      subtitle:     "FINANCIAL DOCUMENT",
      type:         "FINANCIAL",
      fileSize:     "0.5 MB",
      documentCode: "RCP-2025-0823",
    },
  ],
};
import { useEffect, useState } from "react";
import { useHomework } from "../hooks/useHomework";
import { HomeworkCard } from "../components/HomeWorkCard";
import { StudyMaterialCard } from "../components/StudyMaterialCard";
import SubmitHomeworkModal from "../components/SubmitHomeworkModal";
import { GraduationCap } from "lucide-react";
import { getAllAcademicYears, type AcademicYearRecord } from "@/services/academicYear.api";

type Tab = "week" | "all" | "materials";

const TABS = [
  { key: "week" as Tab, label: "This Week", icon: "📅" },
  { key: "all" as Tab, label: "All Homework", icon: "📋" },
  { key: "materials" as Tab, label: "Study Materials", icon: "📚" },
];

interface ShowMoreButtonProps {
  shown: number;
  total: number;
  onShowMore: () => void;
  onShowLess: () => void;
}

const ShowMoreLessButton = ({ shown, total, onShowMore, onShowLess }: ShowMoreButtonProps) => {
  const remaining = total - shown;
  const canShowMore = shown < total;
  const canShowLess = shown > 4;

  return (
    <div className="flex items-center gap-2">
      {canShowMore && (
        <button
          onClick={onShowMore}
          className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl
                     border border-dashed border-indigo-200 bg-indigo-50/50
                     text-sm font-medium text-indigo-600
                     hover:bg-indigo-50 hover:border-indigo-300 transition-colors"
        >
          Show {remaining} more
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M2 5l5 5 5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      )}
      {canShowLess && (
        <button
          onClick={onShowLess}
          className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl
                     border border-dashed border-gray-200 bg-gray-50/50
                     text-sm font-medium text-gray-500
                     hover:bg-gray-100 hover:border-gray-300 transition-colors"
        >
          Show less
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M2 9l5-5 5 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      )}
    </div>
  );
};

export const HomeworkPage = () => {
  const {
    activeTab, setActiveTab,
    homework,
    thisWeekHomework,
    materials,
    loading, error, refetch,
    submitModalOpen,
    selectedHomework,
    openSubmitModal,
    closeSubmitModal,
    handleSubmit,
    studentId,
    studentName,
    studentClass,
    studentSection,
  } = useHomework();

  const [activeAcademicYear, setActiveAcademicYear] = useState<AcademicYearRecord | null>(null);
  const [visibleCount, setVisibleCount] = useState(4);

  useEffect(() => {
    getAllAcademicYears().then(({ data }) => {
      const active = data.find((y) => y.active) ?? data[0] ?? null;
      setActiveAcademicYear(active);
    });
  }, []);

  useEffect(() => {
    setVisibleCount(4);
  }, [activeTab]);

  if (loading) {
    return (
      <div className="p-3 sm:p-6 bg-gray-50 min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-4 border-indigo-700 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-gray-400 font-medium">Loading homework…</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-3 sm:p-6 bg-gray-50 min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-3 text-center">
          <p className="text-sm text-red-500 font-medium">{error}</p>
          <button
            onClick={refetch}
            className="px-4 py-2 text-sm font-semibold bg-indigo-700 text-white rounded-lg hover:bg-indigo-800 transition"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-3 sm:p-6 bg-gray-50 min-h-screen">

      {/* PAGE HEADER */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-[#0B1C30]">My Homework</h1>
        <div className="flex flex-wrap items-center gap-2 mt-1 text-sm text-gray-400">
          {studentName && (
            <span className="font-medium text-gray-600">{studentName}</span>
          )}
          {studentClass && (
            <>
              <span className="text-gray-300">•</span>
              <span className="flex items-center gap-1">
                <GraduationCap size={13} className="text-gray-400" />
                Class {studentClass}
                {studentSection && (
                  <span className="text-gray-400">– {studentSection}</span>
                )}
              </span>
            </>
          )}
          <span className="text-gray-300">•</span>
          <span>
            Academic Year{" "}
            {activeAcademicYear ? activeAcademicYear.yearName : "…"}
          </span>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-4 lg:gap-6">

        {/* SIDEBAR */}
        <aside className="w-full lg:w-48 flex-shrink-0 flex flex-row lg:flex-col gap-3 overflow-x-auto lg:overflow-visible">
          <div className="bg-white border border-gray-100 rounded-xl p-3 shadow-sm">
            <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-widest mb-2 px-1">
              Homework
            </p>
            <nav className="flex lg:flex-col gap-2 lg:gap-1">
              {TABS.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors text-left w-full
                    ${activeTab === tab.key
                      ? "bg-indigo-50 text-indigo-700 font-medium"
                      : "text-gray-500 hover:bg-gray-50"
                    }`}
                >
                  <span>{tab.icon}</span>
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>

          <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-3 text-xs text-indigo-700 leading-relaxed">
            <p className="font-semibold text-indigo-900 mb-1">💡 Tip</p>
            <p>Complete your pending assignments to stay ahead of the deadline!</p>
          </div>
        </aside>

        {/* MAIN */}
        <div className="flex-1 flex flex-col gap-4 min-w-0">

          {/* This Week */}
          {activeTab === "week" && (
            <div className="space-y-3">
              {thisWeekHomework.length === 0 ? (
                <p className="text-sm text-gray-400 p-4">No homework from this day onwards 🎉</p>
              ) : (
                <>
                  {thisWeekHomework.slice(0, visibleCount).map((hw) => (
                    <HomeworkCard key={hw.id} item={hw} onSubmit={openSubmitModal} />
                  ))}
                  {thisWeekHomework.length > 4 && (
                    <ShowMoreLessButton
                      shown={visibleCount}
                      total={thisWeekHomework.length}
                      onShowMore={() => setVisibleCount((p) => p + 4)}
                      onShowLess={() => setVisibleCount(4)}
                    />
                  )}
                </>
              )}
            </div>
          )}

          {/* All Homework */}
          {activeTab === "all" && (
            <div className="space-y-3">
              {homework.length === 0 ? (
                <p className="text-sm text-gray-400 p-4">No homework found.</p>
              ) : (
                <>
                  {homework.slice(0, visibleCount).map((hw) => (
                    <HomeworkCard key={hw.id} item={hw} onSubmit={openSubmitModal} />
                  ))}
                  {homework.length > 4 && (
                    <ShowMoreLessButton
                      shown={visibleCount}
                      total={homework.length}
                      onShowMore={() => setVisibleCount((p) => p + 4)}
                      onShowLess={() => setVisibleCount(4)}
                    />
                  )}
                </>
              )}
            </div>
          )}

          {/* Study Materials */}
          {activeTab === "materials" && (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {materials.slice(0, visibleCount).map((m) => (
                  <StudyMaterialCard key={m.id} item={m} />
                ))}
              </div>
              {materials.length > 4 && (
                <ShowMoreLessButton
                  shown={visibleCount}
                  total={materials.length}
                  onShowMore={() => setVisibleCount((p) => p + 4)}
                  onShowLess={() => setVisibleCount(4)}
                />
              )}
              <div className="flex items-center justify-between gap-4 bg-indigo-50 border border-indigo-100 rounded-xl px-5 py-4">
                <div>
                  <p className="text-sm font-semibold text-gray-800">Need something else?</p>
                  <p className="text-xs text-gray-500 mt-1">
                    If you cannot find a specific study material, please contact your subject teacher or check the departmental library.
                  </p>
                </div>
                <button className="flex-shrink-0 text-xs font-semibold border border-indigo-200 bg-white text-indigo-700 px-4 py-2 rounded-lg hover:bg-indigo-50 transition">
                  Request Material
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Submit Modal */}
      <SubmitHomeworkModal
        open={submitModalOpen}
        onClose={closeSubmitModal}
        homeworkId={selectedHomework?.id ?? ""}
        studentId={studentId}
        onSuccess={(submissionId) => {
          if (selectedHomework) {
            handleSubmit(selectedHomework.id, submissionId);
            refetch();
          }
        }}
        assignment={
          selectedHomework
            ? {
              title: selectedHomework.title,
              subject: selectedHomework.subject,
              className: studentClass,
              dueLabel: selectedHomework.dueDate,
              assignedBy: selectedHomework.assignedBy,
            }
            : undefined
        }
      />
    </div>
  );
};
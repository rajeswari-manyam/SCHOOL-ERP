import { motion } from 'framer-motion';
import {
  Search, MessageCircle, FileText, CheckCircle, XCircle,
  UserPlus, ClipboardCheck, Receipt, Megaphone, Table2,
  Calendar,
} from 'lucide-react';
import type { AdmissionStage } from '../types';

interface AdmissionsPipelineProps {
  pipeline: AdmissionStage[];
  academicYearName?: string;
}

const stageConfig = [
  { key: 'ENQUIRY',   label: 'Enquiry',   gradient: 'from-blue-500 to-blue-700',      icon: Search,       emoji: '🔍' },
  { key: 'INTERVIEW', label: 'Interview', gradient: 'from-purple-500 to-purple-700',  icon: MessageCircle, emoji: '💬' },
  { key: 'DOCS',      label: 'Documents', gradient: 'from-orange-500 to-yellow-600',  icon: FileText,     emoji: '📄' },
  { key: 'CONFIRMED', label: 'Confirmed', gradient: 'from-green-500 to-green-700',    icon: CheckCircle,  emoji: '✅' },
  { key: 'DECLINED',  label: 'Declined',  gradient: 'from-red-500 to-red-700',        icon: XCircle,      emoji: '❌' },
];

const quickActions = [
  { id: 'add-student', label: 'Add Student',    icon: UserPlus       },
  { id: 'attendance',  label: 'Attendance',     icon: ClipboardCheck },
  { id: 'fee-payment', label: 'Fee Payment',    icon: Receipt        },
  { id: 'broadcast',   label: 'Broadcast',      icon: Megaphone      },
  { id: 'enquiry',     label: 'Add Enquiry',    icon: Search         },
  { id: 'report',      label: 'Gen. Report',    icon: Table2         },
];

export function AdmissionsPipeline({ pipeline, academicYearName }: AdmissionsPipelineProps) {
  const stageCountMap = pipeline.reduce<Record<string, number>>((acc, s) => {
    acc[s.stage] = s.count;
    return acc;
  }, {});

  return (
    <div className="bg-white rounded-2xl p-6 shadow-md border border-gray-100">

      {/* ── Section: Admissions Pipeline ── */}
      <div className="mb-6">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h2 className="text-xl font-bold text-gray-900">Admissions Pipeline</h2>
          {academicYearName && (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-indigo-50 px-3 py-1 text-xs font-semibold text-indigo-700 ring-1 ring-indigo-200">
              <Calendar size={12} />
              <span>AY {academicYearName}</span>
            </span>
          )}
        </div>
        <p className="text-sm text-gray-500 mt-1">Track enquiries through each stage</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {stageConfig.map((stage, i) => {
          const count = stageCountMap[stage.key] ?? 0;
          const Icon = stage.icon;
          return (
            <motion.div
              key={stage.key}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06, duration: 0.35 }}
              className={`relative bg-gradient-to-br ${stage.gradient} rounded-2xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 p-5 md:p-6 text-white overflow-hidden`}
            >
              <div className="flex items-start justify-between mb-3">
                <Icon className="h-6 w-6 md:h-7 md:w-7 opacity-80" strokeWidth={2} />
                <span className="text-3xl md:text-4xl font-bold">{count}</span>
              </div>
              <p className="text-sm md:text-base opacity-90 font-medium">{stage.label}</p>
            </motion.div>
          );
        })}
      </div>

      {/* ── Section: Quick Actions ── */}
      <div className="mt-6">
        <h2 className="text-xl font-bold text-gray-900">Quick Actions</h2>
        <p className="text-sm text-gray-500 mt-1">Common tasks at your fingertips</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-4">
        {quickActions.map((action, i) => {
          const Icon = action.icon;
          return (
            <motion.button
              key={action.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25 + i * 0.04, duration: 0.3 }}
              className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300 flex flex-col items-center gap-2 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400"
              aria-label={action.label}
            >
              <Icon className="h-6 w-6 text-gray-700" strokeWidth={1.75} />
              <span className="text-sm font-semibold text-gray-800">{action.label}</span>
            </motion.button>
          );
        })}
      </div>

    </div>
  );
}

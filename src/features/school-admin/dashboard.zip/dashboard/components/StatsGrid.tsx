import { motion } from 'framer-motion';
import { Users, CheckSquare, IndianRupee, UserPlus } from 'lucide-react';
import { cn } from '../../../../utils/cn';
import type { StatsCard } from '../types';

const iconMap = {
  users:      Users,
  check:      CheckSquare,
  rupee:      IndianRupee,
  'user-plus': UserPlus,
};

// Per-card left-border accent and badge colours
const cardAccent: Record<string, { border: string; badge: string; badgeText: string }> = {
  attendance: { border: 'border-l-emerald-500', badge: 'bg-emerald-100', badgeText: 'text-emerald-700' },
  classes:    { border: 'border-l-amber-500',   badge: 'bg-amber-100',   badgeText: 'text-amber-700'   },
  fees:       { border: 'border-l-indigo-500',  badge: 'bg-indigo-100',  badgeText: 'text-indigo-700'  },
  admissions: { border: 'border-l-violet-500',  badge: 'bg-violet-100',  badgeText: 'text-violet-700'  },
};

const defaultAccent = { border: 'border-l-gray-300', badge: 'bg-gray-100', badgeText: 'text-gray-700' };

interface StatsGridProps {
  stats?: StatsCard[];
  loadingStatIds?: Set<string>;
}

export function StatsGrid({ stats = [], loadingStatIds }: StatsGridProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {stats.map((stat, i) => {
        const GhostIcon = iconMap[stat.icon as keyof typeof iconMap] || Users;
        const isLoading = loadingStatIds?.has(stat.id);
        const accent = cardAccent[stat.id] ?? defaultAccent;

        return (
          <motion.div
            key={stat.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05, duration: 0.28, ease: 'easeOut' }}
            className={cn(
              'relative overflow-hidden rounded-xl bg-white border border-l-4 p-4 sm:p-5',
              'flex flex-col min-h-[120px]',
              'shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200',
              stat.alert ? 'border-amber-200 bg-amber-50/30' : 'border-gray-100',
              accent.border
            )}
          >
            {/* Label */}
            <p className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">
              {stat.label}
            </p>

            {/* Value row */}
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              {isLoading ? (
                <div className="h-8 w-24 animate-pulse rounded bg-gray-200" />
              ) : (
                <span className="text-2xl sm:text-3xl font-extrabold leading-none text-gray-900">
                  {stat.value}
                </span>
              )}
              {stat.badge && !isLoading && (
                <span className={cn('rounded-full px-2 py-0.5 text-[10px] sm:text-xs font-bold', accent.badge, accent.badgeText)}>
                  {stat.badge.text}
                </span>
              )}
              {stat.alert && !isLoading && (
                <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[10px] sm:text-xs font-bold text-amber-700">
                  Action needed
                </span>
              )}
            </div>

            {/* Subtitle */}
            {isLoading ? (
              <div className="h-3 w-32 animate-pulse rounded bg-gray-100" />
            ) : (
              <p className="text-[11px] sm:text-xs text-gray-500 leading-normal flex-1">
                {stat.sub}
              </p>
            )}

            {/* Action link */}
            {stat.action && !isLoading && (
              <button
                type="button"
                className="mt-2 text-[11px] sm:text-xs font-semibold text-indigo-600 hover:text-indigo-800 transition-colors text-left w-fit"
              >
                {stat.action.label} →
              </button>
            )}

            {/* Watermark icon */}
            <div className="absolute bottom-2 right-2 opacity-[0.06] pointer-events-none">
              <GhostIcon size={36} strokeWidth={1.5} />
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}

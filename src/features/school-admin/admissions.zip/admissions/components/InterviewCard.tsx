import { useRef, useState, useCallback } from 'react';
import { Calendar, ArrowRight, Clock, User, Upload, X, FileText, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import type { Enquiry } from '../types';
import { useAdmissionsStore } from '../hooks/useAdmissionsStore';
import { useMoveToStage } from '../hooks/useAdmissionsQueries';
import {
  useUploadAdmissionDocuments,
  type UploadProgress,
} from '../hooks/useUploadAdmissionDocuments';
import { Card } from '../../../../components/ui/card';
import { Button } from '../../../../components/ui/button';
import { Badge } from '../../../../components/ui/badge';

// ─── helpers ────────────────────────────────────────────────────────────────

const ACCEPTED_TYPES = [
  'image/jpeg',
  'image/png',
  'image/webp',
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
];
const MAX_FILE_SIZE_MB = 10;
const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;
const MAX_FILES = 10;

function validateFiles(incoming: File[], existing: File[]): { valid: File[]; errors: string[] } {
  const errors: string[] = [];
  const valid: File[] = [];

  if (existing.length + incoming.length > MAX_FILES) {
    errors.push(`You can upload at most ${MAX_FILES} files at once.`);
    return { valid, errors };
  }

  for (const file of incoming) {
    if (!ACCEPTED_TYPES.includes(file.type)) {
      errors.push(`"${file.name}" is not a supported file type.`);
      continue;
    }
    if (file.size > MAX_FILE_SIZE_BYTES) {
      errors.push(`"${file.name}" exceeds the ${MAX_FILE_SIZE_MB} MB limit.`);
      continue;
    }
    if (existing.some((f) => f.name === file.name && f.size === file.size)) {
      errors.push(`"${file.name}" is already added.`);
      continue;
    }
    valid.push(file);
  }
  return { valid, errors };
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

const isDateSoon = (dateStr?: string): { label: string; urgent: boolean } | null => {
  if (!dateStr) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const parts = dateStr.split(/[-/]/);
  if (parts.length !== 3) return null;
  const d = new Date(`${parts[0]}-${parts[1]}-${parts[2]}`);
  if (isNaN(d.getTime())) return null;
  const diff = Math.ceil((d.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  if (diff < 0) return { label: `Overdue by ${Math.abs(diff)}d`, urgent: true };
  if (diff === 0) return { label: 'Today', urgent: true };
  if (diff === 1) return { label: 'Tomorrow', urgent: true };
  if (diff <= 7) return { label: `In ${diff}d`, urgent: false };
  return null;
};

const UnknownStudent = ({ id }: { id: string }) => (
  <span className="text-sm font-medium text-gray-400 italic">Unknown #{id.slice(0, 8)}</span>
);

// ─── sub-components ──────────────────────────────────────────────────────────

interface FileRowProps {
  file: File;
  onRemove: () => void;
  disabled: boolean;
}

function FileRow({ file, onRemove, disabled }: FileRowProps) {
  return (
    <div className="flex items-center gap-2 rounded-md bg-gray-50 px-2 py-1.5">
      <FileText size={12} className="shrink-0 text-amber-500" />
      <span className="min-w-0 flex-1 truncate text-xs text-gray-700">{file.name}</span>
      <span className="shrink-0 text-xs text-gray-400">{formatBytes(file.size)}</span>
      {!disabled && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          className="shrink-0 rounded text-gray-400 hover:text-red-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-300"
          aria-label={`Remove ${file.name}`}
        >
          <X size={12} />
        </button>
      )}
    </div>
  );
}

interface UploadZoneProps {
  isDragging: boolean;
  onDragEnter: (e: React.DragEvent) => void;
  onDragLeave: (e: React.DragEvent) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent) => void;
  onBrowse: () => void;
  disabled: boolean;
}

function UploadZone({
  isDragging,
  onDragEnter,
  onDragLeave,
  onDragOver,
  onDrop,
  onBrowse,
  disabled,
}: UploadZoneProps) {
  return (
    <div
      onDragEnter={onDragEnter}
      onDragLeave={onDragLeave}
      onDragOver={onDragOver}
      onDrop={onDrop}
      onClick={(e) => {
        e.stopPropagation();
        if (!disabled) onBrowse();
      }}
      className={[
        'flex cursor-pointer flex-col items-center gap-1 rounded-lg border-2 border-dashed px-3 py-4 text-center transition-colors',
        isDragging
          ? 'border-amber-400 bg-amber-50'
          : 'border-gray-200 bg-gray-50 hover:border-amber-300 hover:bg-amber-50/50',
        disabled ? 'cursor-not-allowed opacity-60' : '',
      ]
        .filter(Boolean)
        .join(' ')}
    >
      <Upload size={16} className="text-amber-500" />
      <p className="text-xs font-medium text-gray-700">
        {isDragging ? 'Drop files here' : 'Drag & drop or browse'}
      </p>
      <p className="text-[10px] text-gray-400">PDF, Word, JPEG, PNG, WebP · max {MAX_FILE_SIZE_MB} MB · up to {MAX_FILES} files</p>
    </div>
  );
}

interface ProgressBarProps {
  percent: number;
}

function ProgressBar({ percent }: ProgressBarProps) {
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-[10px] text-gray-500">
        <span>Uploading…</span>
        <span>{percent}%</span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-gray-100">
        <motion.div
          className="h-full rounded-full bg-amber-400"
          initial={{ width: 0 }}
          animate={{ width: `${percent}%` }}
          transition={{ ease: 'easeOut', duration: 0.15 }}
        />
      </div>
    </div>
  );
}

// ─── main component ───────────────────────────────────────────────────────────

interface Props {
  enquiry: Enquiry;
  index: number;
}

export function InterviewCard({ enquiry, index }: Props) {
  const { setSelectedEnquiry } = useAdmissionsStore();
  const moveToStage = useMoveToStage();
  const uploadDocuments = useUploadAdmissionDocuments();

  // Upload panel state
  const [uploadOpen, setUploadOpen] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [progress, setProgress] = useState<UploadProgress | null>(null);
  const [uploadDone, setUploadDone] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const dragCounter = useRef(0); // track nested drag events

  const isUploading = uploadDocuments.isPending;
  const soon = isDateSoon(enquiry.interviewDate);

  // ── file handling ──────────────────────────────────────────────────────────

  const addFiles = useCallback(
    (incoming: FileList | File[]) => {
      const arr = Array.from(incoming);
      const { valid, errors } = validateFiles(arr, files);
      setValidationErrors(errors);
      if (valid.length) setFiles((prev) => [...prev, ...valid]);
    },
    [files],
  );

  const removeFile = useCallback((idx: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== idx));
    setValidationErrors([]);
  }, []);

  // ── drag handlers ──────────────────────────────────────────────────────────

  const handleDragEnter = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      dragCounter.current += 1;
      if (!isUploading) setIsDragging(true);
    },
    [isUploading],
  );

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current -= 1;
    if (dragCounter.current === 0) setIsDragging(false);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDragging(false);
      dragCounter.current = 0;
      if (!isUploading && e.dataTransfer.files.length > 0) {
        addFiles(e.dataTransfer.files);
      }
    },
    [isUploading, addFiles],
  );

  // ── upload ────────────────────────────────────────────────────────────────

  const handleUpload = useCallback(
    async (e: React.MouseEvent) => {
      e.stopPropagation();
      if (!files.length || isUploading) return;
      setValidationErrors([]);
      setProgress({ loaded: 0, total: 1, percent: 0 });

      uploadDocuments.mutate(
        {
          enquiryId: enquiry.id,
          files,
          onProgress: setProgress,
        },
        {
          onSuccess: () => {
            setUploadDone(true);
            setFiles([]);
            setProgress(null);
            // auto-close after a moment
            setTimeout(() => {
              setUploadOpen(false);
              setUploadDone(false);
            }, 1800);
          },
          onError: () => {
            setProgress(null);
          },
        },
      );
    },
    [files, isUploading, uploadDocuments, enquiry.id],
  );

  const handleToggleUpload = useCallback(
    (e: React.MouseEvent) => {
      e.stopPropagation();
      if (isUploading) return;
      setUploadOpen((v) => {
        if (v) {
          // closing: reset state
          setFiles([]);
          setValidationErrors([]);
          setProgress(null);
          setUploadDone(false);
        }
        return !v;
      });
    },
    [isUploading],
  );

  // ─────────────────────────────────────────────────────────────────────────

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.04 }}
    >
      <Card
        onClick={() => setSelectedEnquiry(enquiry.id)}
        className="cursor-pointer border-gray-100 p-4 transition-all hover:border-amber-200"
      >
        {/* Header */}
        <div className="mb-2 flex items-start justify-between gap-2">
          <div className="min-w-0 flex-1">
            {enquiry.studentName ? (
              <h3 className="truncate text-sm font-semibold text-gray-900">
                {enquiry.studentName}
              </h3>
            ) : (
              <UnknownStudent id={enquiry.id} />
            )}
          </div>
          {soon && (
            <Badge variant={soon.urgent ? 'red' : 'amber'} className="shrink-0">
              {soon.label}
            </Badge>
          )}
          {!soon && enquiry.interviewDate && (
            <Badge variant="amber" className="shrink-0">
              Scheduled
            </Badge>
          )}
        </div>

        {/* Class + Parent */}
        <div className="mb-2 space-y-1 text-xs text-gray-500">
          <div className="flex gap-1">
            <span className="text-gray-400">Class:</span>
            <span className="font-semibold text-gray-700">
              {enquiry.classApplyingFor || '—'}
            </span>
          </div>
          <div className="flex items-center gap-1">
            <User size={11} className="text-gray-300" />
            <span className="truncate text-gray-600">
              {enquiry.parentName || enquiry.parentPhone || '—'}
            </span>
          </div>
        </div>

        {/* Interview date */}
        {enquiry.interviewDate && (
          <div className="mb-2 flex items-center gap-1.5 rounded-lg bg-amber-50 px-2 py-1.5 text-xs text-amber-700">
            <Calendar size={12} />
            <span className="font-medium">{enquiry.interviewDate}</span>
          </div>
        )}

        {/* Interview note */}
        {enquiry.interviewNote && (
          <div className="mb-3 flex items-start gap-1.5 rounded-lg bg-gray-50 px-2 py-1.5 text-xs italic text-gray-500">
            <Clock size={11} className="mt-0.5 shrink-0 text-gray-300" />
            <span>{enquiry.interviewNote}</span>
          </div>
        )}

        {/* ── Upload Documents Panel ─────────────────────────────────────── */}
        <div className="mb-2">
          {/* Toggle button */}
          <Button
            type="button"
            onClick={handleToggleUpload}
            disabled={isUploading}
            variant="outline"
            size="sm"
            className={[
              'flex w-full items-center justify-center gap-1.5 transition-colors',
              uploadOpen ? 'border-amber-300 bg-amber-50 text-amber-700 hover:bg-amber-100' : '',
            ]
              .filter(Boolean)
              .join(' ')}
          >
            <Upload size={12} />
            {uploadOpen ? 'Hide Upload' : 'Upload Documents'}
          </Button>

          {/* Collapsible panel */}
          <AnimatePresence initial={false}>
            {uploadOpen && (
              <motion.div
                key="upload-panel"
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2, ease: 'easeInOut' }}
                className="overflow-hidden"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="mt-2 space-y-2">
                  {/* Hidden file input */}
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    accept={ACCEPTED_TYPES.join(',')}
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files) addFiles(e.target.files);
                      e.target.value = '';
                    }}
                    aria-label="Upload admission documents"
                  />

                  {/* Success state */}
                  {uploadDone ? (
                    <div className="flex flex-col items-center gap-1.5 rounded-lg bg-green-50 px-3 py-4 text-center">
                      <CheckCircle size={20} className="text-green-500" />
                      <p className="text-xs font-medium text-green-700">Documents uploaded!</p>
                    </div>
                  ) : (
                    <>
                      {/* Drop zone */}
                      <UploadZone
                        isDragging={isDragging}
                        onDragEnter={handleDragEnter}
                        onDragLeave={handleDragLeave}
                        onDragOver={handleDragOver}
                        onDrop={handleDrop}
                        onBrowse={() => fileInputRef.current?.click()}
                        disabled={isUploading}
                      />

                      {/* File list */}
                      {files.length > 0 && (
                        <div className="space-y-1">
                          {files.map((file, idx) => (
                            <FileRow
                              key={`${file.name}-${file.size}`}
                              file={file}
                              onRemove={() => removeFile(idx)}
                              disabled={isUploading}
                            />
                          ))}
                        </div>
                      )}

                      {/* Validation errors */}
                      {validationErrors.length > 0 && (
                        <div className="rounded-md bg-red-50 px-2 py-1.5 space-y-0.5">
                          {validationErrors.map((err) => (
                            <p key={err} className="text-[10px] text-red-600">
                              {err}
                            </p>
                          ))}
                        </div>
                      )}

                      {/* Progress bar */}
                      {progress && <ProgressBar percent={progress.percent} />}

                      {/* Upload button */}
                      {files.length > 0 && !isUploading && (
                        <Button
                          type="button"
                          onClick={handleUpload}
                          size="sm"
                          className="flex w-full items-center justify-center gap-1.5 bg-amber-500 text-white hover:bg-amber-600"
                        >
                          <Upload size={12} />
                          Upload {files.length} {files.length === 1 ? 'file' : 'files'}
                        </Button>
                      )}

                      {isUploading && (
                        <p className="text-center text-[10px] text-gray-400">
                          Please wait while files are uploading…
                        </p>
                      )}
                    </>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Move to Docs action */}
        <Button
          onClick={(e) => {
            e.stopPropagation();
            moveToStage.mutate({ id: enquiry.id, stage: 'docs_verified' });
          }}
          disabled={moveToStage.isPending || isUploading}
          variant="outline"
          size="sm"
          className="flex w-full items-center justify-center gap-1"
        >
          Move to Docs <ArrowRight size={12} />
        </Button>
      </Card>
    </motion.div>
  );
}
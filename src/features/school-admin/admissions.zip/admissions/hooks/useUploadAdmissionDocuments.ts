import { useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { ADMISSIONS_KEYS } from './useAdmissionsQueries';

export interface UploadProgress {
  loaded: number;
  total: number;
  percent: number;
}

export interface UploadAdmissionDocumentsPayload {
  enquiryId: string;
  files: File[];
  onProgress?: (progress: UploadProgress) => void;
}

async function uploadAdmissionDocuments({
  enquiryId,
  files,
  onProgress,
}: UploadAdmissionDocumentsPayload): Promise<void> {
  const formData = new FormData();
  formData.append('enquiry_id', enquiryId);
  files.forEach((file) => formData.append('documents', file));

  await new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();

    xhr.upload.addEventListener('progress', (event) => {
      if (event.lengthComputable && onProgress) {
        onProgress({
          loaded: event.loaded,
          total: event.total,
          percent: Math.round((event.loaded / event.total) * 100),
        });
      }
    });

    xhr.addEventListener('load', () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        resolve();
      } else {
        let message = `Upload failed (${xhr.status})`;
        try {
          const body = JSON.parse(xhr.responseText);
          if (body?.detail || body?.message) {
            message = body.detail ?? body.message;
          }
        } catch {
          // ignore parse errors
        }
        reject(new Error(message));
      }
    });

    xhr.addEventListener('error', () => reject(new Error('Network error during upload')));
    xhr.addEventListener('abort', () => reject(new Error('Upload cancelled')));

    xhr.open('POST', 'http://localhost:4000/tenant/uploadadmissiondocument/');
    // Add auth header if your app uses token-based auth
    // const token = getAuthToken();
    // if (token) xhr.setRequestHeader('Authorization', `Bearer ${token}`);

    xhr.send(formData);
  });
}

export function useUploadAdmissionDocuments() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: uploadAdmissionDocuments,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ADMISSIONS_KEYS.enquiries() });
      qc.invalidateQueries({ queryKey: ADMISSIONS_KEYS.stats() });
      toast.success('Documents uploaded successfully');
    },
    onError: (error: Error) => {
      toast.error(error.message ?? 'Failed to upload documents');
    },
  });
}
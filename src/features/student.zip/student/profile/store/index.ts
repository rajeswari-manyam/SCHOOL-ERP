export * from "./mockProfileData";

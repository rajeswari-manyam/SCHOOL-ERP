import type { Homework, StudyMaterial } from "../types/homework.types";

export const homeworkData: Homework[] = [
  {
    id: "1",
    subject: "ENGLISH",
    subjectColor: "blue",
    title: "Essay — My Favourite Festival",
    description:
      "Students are required to write a descriptive essay (300-400 words) about their favourite cultural festival, focusing on traditions, food, and family significance.",
    due: "7 Apr",
    dueLabel: "Tomorrow",
    teacher: "Priya Reddy ma'am",
    teacherInitials: "PR",
    day: 7,
    status: "PENDING",
    attachment: { name: "essay-guidelines.pdf" },
    whatsappNotified: "3 Apr",
  },
  {
    id: "2",
    subject: "MATHEMATICS",
    subjectColor: "orange",
    title: "Exercise 5.3 — Quadratic Equations",
    description:
      "Complete all problems from Exercise 5.3 in the textbook. Ensure all steps of the quadratic formula applications are shown clearly in the homework notebook.",
    due: "9 Apr",
    teacher: "Kiran Kumar sir",
    teacherInitials: "KK",
    day: 9,
    status: "PENDING",
  },
  {
    id: "3",
    subject: "SCIENCE",
    subjectColor: "green",
    title: "Lab Report — Photosynthesis Experiment",
    description:
      "Draft the final lab report based on the observations from last Wednesday's experiment. Include charts for CO2 absorption rates observed.",
    due: "11 Apr",
    teacher: "Dr. Sunita Verma",
    teacherInitials: "SV",
    day: 11,
    status: "PENDING",
    attachment: { name: "lab-report-template" },
  },
  {
    id: "4",
    subject: "ENGLISH",
    subjectColor: "blue",
    title: "Grammar Exercise Ch.4",
    description: "Complete exercises on passive voice and reported speech from Chapter 4.",
    due: "8 Apr",
    teacher: "Priya Reddy ma'am",
    teacherInitials: "PR",
    day: 8,
    status: "NOT TRACKED",
  },
  {
    id: "5",
    subject: "ENGLISH",
    subjectColor: "blue",
    title: "Reading Comprehension P7",
    description: "Read passage on page 7 and answer all comprehension questions.",
    due: "9 Apr",
    teacher: "Priya Reddy ma'am",
    teacherInitials: "PR",
    day: 9,
    status: "PENDING",
  },
  {
    id: "6",
    subject: "MATHEMATICS",
    subjectColor: "orange",
    title: "Chapter 4 Practice",
    description: "Solve all practice questions from Chapter 4 revision sheet.",
    due: "3 Apr",
    teacher: "Kiran Kumar sir",
    teacherInitials: "KK",
    day: 8,
    status: "SUBMITTED",
  },
  {
    id: "7",
    subject: "SCIENCE",
    subjectColor: "green",
    title: "Chapter 6 Notes",
    description: "Prepare notes on Chapter 6: Light and Optics.",
    due: "28 Mar",
    teacher: "Dr. Sunita Verma",
    teacherInitials: "SV",
    day: 10,
    status: "SUBMITTED",
  },
];

export const studyMaterials: StudyMaterial[] = [
  {
    id: "1",
    title: "Grammar Notes.pdf",
    subject: "English",
    class: "Class 10A",
    uploaded: "2 Apr",
    type: "pdf",
  },
  {
    id: "2",
    title: "Algebra Formula Sheet.pdf",
    subject: "Maths",
    class: "Class 10A",
    uploaded: "1 Apr",
    type: "pdf",
  },
  {
    id: "3",
    title: "History Timeline.jpg",
    subject: "SST",
    class: "Class 10A",
    uploaded: "28 Mar",
    type: "jpg",
  },
  {
    id: "4",
    title: "Khan Academy — English Videos",
    subject: "English",
    class: "Class 10A",
    uploaded: "25 Mar",
    type: "link",
    isLink: true,
  },
  {
    id: "5",
    title: "Essay Writing Guide.docx",
    subject: "English",
    class: "Class 10A",
    uploaded: "25 Mar",
    type: "doc",
  },
  {
    id: "6",
    title: "Physics Formula Sheet.pdf",
    subject: "Science",
    class: "Class 10A",
    uploaded: "20 Mar",
    type: "pdf",
  },
];

export const DAYS = [
  { day: 7, label: "MON" },
  { day: 8, label: "TUE" },
  { day: 9, label: "WED" },
  { day: 10, label: "THU" },
  { day: 11, label: "FRI" },
];

// src/recommended-resources/data/mock.ts

import type { RecommendedResource } from "../types/homework.types";

export const resources: RecommendedResource[] = [
  {
    id: "1",
    title: "Math Formulas 101",
    subtitle: "Class 10 Revision",
    type: "download",
  },
  {
    id: "2",
    title: "Light Refraction Video",
    subtitle: "Science Lab Supplement",
    type: "link",
  },
];
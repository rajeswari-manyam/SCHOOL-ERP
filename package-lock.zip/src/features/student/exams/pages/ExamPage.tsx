// pages/ExamsPage.tsx
import { useExamData } from "../hooks/useExam";
import { UpcomingSection } from "../components/UpcomingSection";
import { ResultsSection } from "../components/ResultSection";
// import { ReportCardSection } from "../components/ReportCardSection";
// import { SyllabusSection } from "../components/SyllabusSection";

// ── Change these to come from auth context / route params as needed ──
const CLASS_NAME = "10";
const SECTION_NAME = "A";
const STUDENT_ID = "";
const EXAM_TYPE = "Midterm";
const ACADEMIC_YEAR = "2025-2026";

const tabs = [
  { id: "upcoming", label: "Upcoming Exams" },
  { id: "results", label: "Results" },
  // { id: "report", label: "Report Card" },
  // { id: "syllabus", label: "Syllabus" },
] as const;

export const ExamsPage = () => {
  const {
    activeTab,
    setActiveTab,
    exams,
    examsLoading,
    examsError,
    refetchExams,
    examResult,
    // report,
    // syllabus,
    // unitTestSyllabus,
    // deadlines,
  } = useExamData(CLASS_NAME, SECTION_NAME, STUDENT_ID, EXAM_TYPE, ACADEMIC_YEAR);

  return (
    <div className="mx-auto max-w-7xl px-2 sm:px-3 py-3 sm:py-4 space-y-4">

      {/* ================= HEADER ================= */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold text-indigo-700">
            My Exams & Results
          </h1>
          <p className="text-sm text-gray-500">
            Class {CLASS_NAME}{SECTION_NAME} | Academic Year 2024-25
          </p>
        </div>

        <div className="
          flex items-center gap-1
          rounded-lg border border-gray-200 bg-white
          px-3 py-1.5 text-sm text-gray-700
          transition hover:border-indigo-200 hover:shadow-sm
        ">
          2024-25
          <svg
            className="h-4 w-4 text-gray-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={2}
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </div>

      {/* ================= TABS ================= */}
      <div className="flex border-b border-gray-200 overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`
              relative px-4 py-3 text-sm font-medium transition whitespace-nowrap
              ${
                activeTab === tab.id
                  ? "text-indigo-600"
                  : "text-gray-500 hover:text-gray-700"
              }
            `}
          >
            {tab.label}
            {activeTab === tab.id && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600 rounded-t-full" />
            )}
          </button>
        ))}
      </div>

      {/* ================= CONTENT AREA ================= */}
      <div className="pt-2 transition-all duration-200 space-y-4">

        {/* ── Upcoming Exams (API-driven) ── */}
        <div className="rounded-xl border border-transparent transition-all duration-200 hover:border-indigo-200 hover:shadow-sm">
          {activeTab === "upcoming" && (
            <>
              {/* Loading */}
              {examsLoading && (
                <div className="flex items-center justify-center py-12 text-sm text-gray-400">
                  <svg className="animate-spin h-5 w-5 mr-2 text-indigo-500" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                  </svg>
                  Loading exam timetable…
                </div>
              )}

              {/* Error */}
              {!examsLoading && examsError && (
                <div className="flex flex-col items-center gap-3 py-12 text-sm text-red-500">
                  <span>{examsError}</span>
                  <button
                    onClick={refetchExams}
                    className="rounded-lg border border-red-200 px-4 py-1.5 text-xs text-red-500 hover:bg-red-50 transition"
                  >
                    Retry
                  </button>
                </div>
              )}

              {/* Data */}
              {!examsLoading && !examsError && (
                <UpcomingSection exams={exams} />
              )}
            </>
          )}
        </div>

        <div className="rounded-xl border border-transparent transition-all duration-200 hover:border-indigo-200 hover:shadow-sm">
          {activeTab === "results" && examResult && (
            <ResultsSection examResult={examResult} />
          )}
        </div>

        {/* <div className="rounded-xl border border-transparent transition-all duration-200 hover:border-indigo-200 hover:shadow-sm">
          {activeTab === "report" && report && (
            <ReportCardSection report={report} />
          )}
        </div> */}

        {/* <div className="rounded-xl border border-transparent transition-all duration-200 hover:border-indigo-200 hover:shadow-sm">
          {activeTab === "syllabus" && (
            <SyllabusSection
              syllabus={syllabus}
              unitTestSyllabus={unitTestSyllabus}
              deadlines={deadlines}
            />
          )}
        </div> */}
      </div>
    </div>
  );
};